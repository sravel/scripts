pyqt4topyqt5
============

pyqt4 -> pyqt5

## Usage
```
usage: pyqt4topyqt5.py [-h] [--nosubdir] [--followlinks] [-o O]
                       [--diff [DIFF]] [--diffs] [--nolog] [--nopyqt5]
                       path
```

Basic example: porting the content of `pyqt4app` to pyqt5 in the directory `pyqt5app`:
```
pyqt4topyqt5.py pyqt4app -o pyqt5app
```
